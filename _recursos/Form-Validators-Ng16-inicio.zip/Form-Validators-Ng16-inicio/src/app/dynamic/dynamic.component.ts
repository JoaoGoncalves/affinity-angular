import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-dynamic',
  templateUrl: './dynamic.component.html',
  styleUrls: ['./dynamic.component.css']
})
export class DynamicComponent implements OnInit {
  myFormModel!: FormGroup;
  countryCtrl!: FormControl;
  phoneCtrl!: FormControl;

  constructor(private fb:FormBuilder){
    this.myFormModel = fb.group({
      country: [''],
      phone: [''],
    })
  }

  ngOnInit(): void {
    this.countryCtrl = this.myFormModel.get('country') as FormControl;
    this.phoneCtrl = this.myFormModel.get('phone') as FormControl;

    this.countryCtrl.valueChanges.subscribe( country => {
      if (country === 'PT'){
        this.phoneCtrl.setValidators([Validators.minLength(9)]);
      } else {
        this.phoneCtrl.setValidators([Validators.minLength(6)]);
      }
      this.phoneCtrl.updateValueAndValidity();
    })
  }


}
