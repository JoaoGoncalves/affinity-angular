import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { equalValidator, ssValidator } from '../myValidatorsLib';

@Component({
  selector: 'app-group',
  templateUrl: './group.component.html',
  styleUrls: ['./group.component.css']
})
export class GroupComponent {
  formModel!: FormGroup;

  constructor(private fb: FormBuilder){
    this.formModel = fb.group({
      username: ['', Validators.required],
      ss: ['', ssValidator],
      passwords: fb.group({
        password: ['', Validators.minLength(5)],
        pconfirm: '',
      }, {validators: equalValidator})
    })
  }
}
