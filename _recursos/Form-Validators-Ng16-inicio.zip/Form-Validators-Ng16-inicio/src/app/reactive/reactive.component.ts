import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive',
  templateUrl: './reactive.component.html',
  styleUrls: ['./reactive.component.css']
})
export class ReactiveComponent {
  myFormModel!: FormGroup;

  constructor(private fb:FormBuilder){
    this.myFormModel = fb.group({
      phone: ['', {
        validators: [
          Validators.required,
          Validators.minLength(9),
          Validators.pattern('[0-9]*'),
        ], updateOn: 'blur'
      }]
    })
  }

  get phone(){
    return this.myFormModel.get('phone');
  }

  onSubmit(){
    console.log(this.myFormModel.value);
  }
}
