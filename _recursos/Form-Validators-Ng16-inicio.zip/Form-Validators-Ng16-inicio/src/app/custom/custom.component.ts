import { Component } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ssValidator } from '../myValidatorsLib';

@Component({
  selector: 'app-custom',
  templateUrl: './custom.component.html',
  styleUrls: ['./custom.component.css']
})
export class CustomComponent {

  myFormModel!: FormGroup;

  constructor(){
    this.myFormModel = new FormGroup({
      segSocial: new FormControl('', ssValidator),
    })
  }

}
